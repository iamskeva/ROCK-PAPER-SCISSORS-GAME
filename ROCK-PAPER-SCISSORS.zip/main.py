import random

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

choices = [rock, paper, scissors]
myChoice = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors. \n"))

print(f"you choose {myChoice}")
print(choices[myChoice])

systemChoice = random.randint(0, 2)
systemResult = (choices[systemChoice])

print(f"Computer choose: {systemResult}")

if myChoice >= 3 and myChoice < 0:
    print("invalid command")
elif myChoice == 0 and systemChoice == 2:
    print("You win!")
elif systemChoice == 0 and myChoice == 2:
    print("You lose!")
elif myChoice > systemChoice:
    print("You win!")
elif systemChoice > myChoice:
    print("You lose!")
else:
    print("It's a draw!")

